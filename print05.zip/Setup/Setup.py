from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QLineEdit,QDialog
from PySide6.QtCore import QSize


class SetupPage(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('个人设置')
  
        # 固定窗口大小
        self.setMinimumSize(QSize(400, 300))  


        self.lb = QLabel('个人信息设置页面')

        self.mainLayout = QVBoxLayout()
        self.mainLayout.addWidget(self.lb)
        self.setLayout(self.mainLayout)