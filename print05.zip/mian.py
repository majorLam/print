from PySide6.QtWidgets import QPushButton,QApplication, QWidget,QHBoxLayout,QVBoxLayout,QStackedWidget
from PySide6.QtCore import QSize
from Home.Home import HomePage
from Home.Home02 import HomePage02
from Setup.Setup import SetupPage


class MyWidow(QWidget):
    def __init__(self):
        super().__init__()
        #主窗口固定大小
        self.setMinimumSize(QSize(800, 500))  
        # self.setMaximumSize(QSize(300, 300))

        self.leftMain()
        self.righttMain()
        self.SetupPage01 = SetupPage()# 子窗口添加主布局中

        # #主窗口布局
        self.MainLayout = QHBoxLayout(self) #水平布局
        self.MainLayout.addWidget(self.leftMainPage,1) 
        self.MainLayout.addWidget(self.righttMainPage,5)


    def leftMain(self):
        #左布局
        self.leftMainPage = QWidget() #创建页面
        leftMainPageLayout = QVBoxLayout(self.leftMainPage) # 左布局为垂直布局
        #左上布局
        self.LeftUpper = QWidget()
        LeftUpperLayout = QVBoxLayout( self.LeftUpper)
        LeftUpperBUtton = ['首页','第二页']
        # 遍历列表，将每个按钮添加到左侧布局中
        for index, text in enumerate(LeftUpperBUtton):  
            button = QPushButton(text) 
            LeftUpperLayout.addWidget(button) 
            button.clicked.connect(lambda _, i=index: self.righttMainPage.setCurrentIndex(i))  #左布局控制着右布局的跳转，RighPagetLayout
        #左下布局
        self.LeftLower = QWidget()
        LeftLowerLayout = QVBoxLayout( self.LeftLower)
        setupButton = QPushButton('设置')
        setupButton.clicked.connect(self.openSetupPage) #添加事件，打开设置子窗口
        LeftLowerLayout.addWidget(setupButton)
        # 添加进左布局
        leftMainPageLayout.addWidget(self.LeftUpper)
        leftMainPageLayout.addStretch(1)
        leftMainPageLayout.addWidget(self.LeftLower)

    def righttMain(self):
        #右布局
        self.righttMainPage = QStackedWidget() #创建页面
        #使用单独的函数创建点击页面
        self.HomePage = HomePage()
        self.HomePage02 = HomePage02()
        #将页面添加到QStackedWidget
        self.righttMainPage.addWidget(self.HomePage)
        self.righttMainPage.addWidget(self.HomePage02)

    def openSetupPage(self):  
        # 创建子窗口实例并显示为模态对话框  
        self.SetupPage01 = SetupPage(self)  # 将主窗口作为父窗口传递给子窗口（可选，但有助于管理窗口层级）  
        self.SetupPage01.exec()  # 使用exec()而不是show()来显示模态对话框  

if __name__=='__main__':
    app = QApplication([])
    window = MyWidow()
    window.show()
    app.exec()